//
//  LoadingView.h
//  LiveLoop
//  
//  Created by Vijay on 15/12/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface LoadingViewFB : NSObject
+(void)displayLoadingIndicator;
+(void)removeLoadingIndicator;
@end

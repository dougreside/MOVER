//
//  MenuObject.m
//  MuslimCare
//
//  Created by kiwitech on 4/23/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//


#import "MenuObject.h"

@implementation MenuObject
@synthesize viewController;
@synthesize menuButtonTitle;
@synthesize normalBtnImage;
@synthesize selectedBtnImage;
@synthesize buttonFrame;
@end
//
//  Bookmark.m
//  NYPL
//
//  Created by shahnwaz on 11/2/12.
//  Copyright (c) 2012 shahnwaz. All rights reserved.
//

#import "Bookmark.h"

@implementation Bookmark
@synthesize _id,playId,versionNo;
@synthesize playAuthorName,playTitle,imageName;
@end

//
//  PlayCustomCell.m
//  NYPL
//
//  Created by kiwitech on 26/10/12.
//  Copyright (c) 2012 shahnwaz. All rights reserved.
//

#import "PlayCustomCell.h"

@implementation PlayCustomCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self){}
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end

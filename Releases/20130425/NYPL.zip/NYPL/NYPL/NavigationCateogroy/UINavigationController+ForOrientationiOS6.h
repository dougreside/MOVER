//
//  UINavigationController+ForOrientationiOS6.h
//  Elsevier
//
//  Created by kiwitech on 25/09/12.
//
//



@interface UINavigationController (ForOrientationiOS6)

@end

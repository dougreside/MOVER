//
//  AboutUsViewController.h
//  NYPL
//
//  Created by shahnwaz on 10/23/12.
//  Copyright (c) 2012 shahnwaz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutUsViewController : UIViewController
{
    IBOutlet UILabel    *titleLabel;
}
-(IBAction)Back_Clicked:(id)sender;
@end
